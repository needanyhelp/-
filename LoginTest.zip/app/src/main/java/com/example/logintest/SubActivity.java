package com.example.logintest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class SubActivity extends AppCompatActivity {
    private Button to_board;
    private Button to_camera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub);

        to_board = (Button) findViewById(R.id.board);
        to_board.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SubActivity.this, BoardActivity.class));
            }
        });

        to_camera = (Button) findViewById(R.id.camera);


        to_camera.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent =new Intent();
                intent.setClassName(SubActivity.this, "com.johnolafenwa.pytorchandroid.Main2Activity");
                startActivity(intent);
                //startActivity(new Intent(SubActivity.this, com.johnolafenwa.pytorchandroid.Result.class));

            }
        });


    }
}
