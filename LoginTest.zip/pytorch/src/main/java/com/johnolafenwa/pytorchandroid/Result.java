package com.johnolafenwa.pytorchandroid;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        Bitmap imageBitmap = (Bitmap) getIntent().getBundleExtra("imagedata").get("data");

        final String pred = getIntent().getStringExtra("pred");

        ImageView imageView = findViewById(R.id.image);
        imageView.setImageBitmap(imageBitmap);

        TextView textView = findViewById(R.id.label);
        textView.setText(pred);

        Button button = findViewById(R.id.back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Result.this, MainnewActivity.class));
            }
        });

        Button read = (Button)findViewById(R.id.read);
        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    String result;
                    CustomTask task = new CustomTask();
                    //result = task.execute("rain483","1234").get();
                    //result = task.execute("read"+editText1.getText().toString()).get();
                    //Log.i("return value",result);
                    result = task.execute("read",pred,"","","","").get();
                    //Log.i("result",result);
                    String[] array = result.split("#");

                    Log.i("return value",array[0]);
                    Log.i("return value",array[1]);
                    Log.i("return value",array[2]);
                    Log.i("return value",array[3]);
                    Log.i("return value",array[4]);

                    //array[1]=array[1].toString();

                    Intent rintent = new Intent(Result.this, recipeInfobyphoto.class);

                    if(array.length==5) {
                        rintent.putExtra("foodname", array[0]);
                        rintent.putExtra("calories", array[1]);
                        rintent.putExtra("time", array[2]);
                        rintent.putExtra("ingredient", array[3]);
                        rintent.putExtra("reference", array[4]);

                        startActivity(rintent);
                    }
                    else{
                        AlertDialog.Builder builder = new AlertDialog.Builder(Result.this);
                        builder.setTitle("WARNING");
                        builder.setMessage("recipe information is not enough!\nplease update.");
                        builder.setNeutralButton("cancel",null);
                        builder.create().show();

                    }








                } catch (Exception e) {

                }
            }
        });



    }

    class CustomTask extends AsyncTask<String, Void, String> {
        String sendMsg, receiveMsg;
        @Override
        protected String doInBackground(String... strings) {
            try {
                String str;
                //http://10.0.2.2:8070/pro07/member3
                //http://54.159.143.175:8080/recipeFinder/member3
                //http://54.159.143.175:8080/recipeFinder/member3
                //URL url = new URL("http://54.159.143.175:8080/recipeFinder/member3");
                URL url = new URL("http://54.159.143.175:8090/please5/member3");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Accept-Charset", "UTF-8");
                //conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                OutputStreamWriter osw = new OutputStreamWriter(conn.getOutputStream());
                //sendMsg = "id="+strings[0]+"&pwd="+strings[1];
                sendMsg = "command="+strings[0]+"&foodname="+strings[1]+"&calories="+strings[2]+"&time="+strings[3]+"&ingredient="+strings[4]+"&reference="+strings[5];

                osw.write(sendMsg);
                osw.flush();



                /*
                try{
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("command",strings[0]);
                    jsonObject.put("foodname",strings[1]);
                    jsonObject.put("calories",strings[2]);
                    jsonObject.put("time",strings[3]);
                    jsonObject.put("ingredient",strings[4]);
                    jsonObject.put("reference",strings[5]);

                    //JSONArray jsonArray= new JSONArray();
                    //jsonArray.put(jsonObject);
                    //JSONObject jsonMain= new JSONObject();
                    //jsonMain.put("dataset",jsonArray);


                    osw.write("jsonString="+jsonObject.toString());
                    osw.flush();
                }

                catch(JSONException e){
                    e.printStackTrace();
                }
                */

                //osw.write(jsonmain);
                if(conn.getResponseCode() == conn.HTTP_OK) {
                    InputStreamReader tmp = new InputStreamReader(conn.getInputStream(), "UTF-8");
                    BufferedReader reader = new BufferedReader(tmp);
                    StringBuffer buffer = new StringBuffer();
                    int check=0;
                    while ((str = reader.readLine()) != null) {
                        buffer.append(str);
                        check++;
                    }

                    Log.i("count",Integer.toString(check));
                    receiveMsg = buffer.toString();
                    Log.i("name",receiveMsg);

                    /*
                    try{
                        //
                        Log.i("test",buffer.toString());
                        String jsonString=buffer.toString();
                        JSONObject resultJson= new JSONObject(jsonString);
                        receiveMsg+=resultJson.getString("foodname");
                        receiveMsg+=resultJson.getInt("calories");
                        receiveMsg+=resultJson.getString("time");
                        receiveMsg+=resultJson.getString("ingredient");
                        receiveMsg+=resultJson.getString("reference");
                    }

                    catch(JSONException e){
                        e.printStackTrace();
                    }
                    */

                } else {
                    Log.i("communication result:", conn.getResponseCode()+"error");
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return receiveMsg;
        }
    }
}
