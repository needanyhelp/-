package com.johnolafenwa.pytorchandroid;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class recipeInfobyphoto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipeinfo);
        Intent intent = getIntent();

        TextView tx1 = (TextView)findViewById(R.id.textView1); /*TextView선언*/
        TextView tx2 = (TextView)findViewById(R.id.textView2);
        TextView tx3 = (TextView)findViewById(R.id.textView3);
        TextView tx4 = (TextView)findViewById(R.id.textView4);
        TextView tx5 = (TextView)findViewById(R.id.textView5);

        Button button = findViewById(R.id.back);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(recipeInfobyphoto.this, MainnewActivity.class));
            }
        });


        String foodname = intent.getExtras().getString("foodname");
        String calories = intent.getExtras().getString("calories");
        String time = intent.getExtras().getString("time");
        String ingredient = intent.getExtras().getString("ingredient");
        String reference = intent.getExtras().getString("reference");

        tx1.setText(foodname);
        tx2.setText(calories);
        tx3.setText(time);
        tx4.setText(ingredient);
        tx5.setText(reference);
    }



}